﻿using UnityEngine;
using System.Numerics;
using Menu.Remix.MixedUI;

public class RezSpiderOptions : OptionInterface
{


    public RezSpiderOptions()
    {
        //RezSpiderOptions.hardMode = this.config.Bind<bool>("hardMode", true, new ConfigurableInfo("(This is just info I guess)", null, "", new object[] { "something idk" }));


        RezSpiderOptions.DartCapacity = this.config.Bind<int>("DartCapacity", 3, new ConfigAcceptableRange<int>(1, 20));
        RezSpiderOptions.BiteDamage = this.config.Bind<float>("BiteDamage", 5f, new ConfigAcceptableRange<float>(1f, 100f));
        RezSpiderOptions.BiteOP = this.config.Bind<bool>("BiteOP", false);
        RezSpiderOptions.DartFireRate = this.config.Bind<float>("DartFireRate", 5, new ConfigAcceptableRange<float>(0, 60));
        RezSpiderOptions.DartBindThrow = this.config.Bind<bool>("DartBindThrow", true);
        RezSpiderOptions.DartAndHold = this.config.Bind<bool>("DartAndHold", false);
        RezSpiderOptions.DartBind1 = this.config.Bind<KeyCode>("DartBind1", KeyCode.None);
        RezSpiderOptions.DartBind2 = this.config.Bind<KeyCode>("DartBind2", KeyCode.None);
        RezSpiderOptions.DartBind3 = this.config.Bind<KeyCode>("DartBind3", KeyCode.None);
        RezSpiderOptions.DartBind4 = this.config.Bind<KeyCode>("DartBind4", KeyCode.None);
        //RezSpiderOptions.FoodMin = this.config.Bind<int>("FoodMin", 8, new ConfigAcceptableRange<int>(1, 20));
        //RezSpiderOptions.FoodMax = this.config.Bind<int>("FoodMax", 16, new ConfigAcceptableRange<int>(1, 40));
        /*
        RezSpiderOptions.JumpPower = this.config.Bind<float>("JumpPower", 0.25f, new ConfigAcceptableRange<float>(-1f, 3f));
        RezSpiderOptions.CatWeight = this.config.Bind<float>("CatWeight", 1.5f, new ConfigAcceptableRange<float>(0f, 5f));
        RezSpiderOptions.CatClimb = this.config.Bind<float>("CatClimb", 2.5f, new ConfigAcceptableRange<float>(0f, 5f));
        RezSpiderOptions.CatTunnel = this.config.Bind<float>("CatTunnel", 3f, new ConfigAcceptableRange<float>(0f, 5f));
        RezSpiderOptions.CatCrawl = this.config.Bind<float>("CatCrawl", 3f, new ConfigAcceptableRange<float>(0f, 5f));
        RezSpiderOptions.CatWalk = this.config.Bind<float>("CatWalk", 1f, new ConfigAcceptableRange<float>(0f, 5f));
        */
    }




    public static Configurable<int> DartCapacity;
    public static Configurable<float> BiteDamage;
    public static Configurable<float> DartFireRate;
    public static Configurable<bool> DartBindThrow;
    public static Configurable<bool> DartAndHold;
    public static Configurable<KeyCode> DartBind1;
    public static Configurable<KeyCode> DartBind2;
    public static Configurable<KeyCode> DartBind3;
    public static Configurable<KeyCode> DartBind4;
    public static Configurable<bool> BiteOP;
   // public bool menucanselect = true;     //was meant for hiding buttons when set to false
    // public static Configurable<int> FoodMin;
    // public static Configurable<int> FoodMax;
    /*
    public static Configurable<float> JumpPower;
    public static Configurable<float> CatWeight;
    public static Configurable<float> CatClimb;
    public static Configurable<float> CatTunnel;
    public static Configurable<float> CatCrawl;
    public static Configurable<float> CatWalk;
    */

    public override void Update()
    {
        base.Update();

        /*                              //First attempting to have buttons disapear with a bool
        if (RezSpiderOptions.DartBindThrow != null)
        {
            if (RezSpiderOptions.DartBindThrow.Value == false)
            {
                menucanselect = false;
            }
            else
            {
                menucanselect = true;
            }
        }
       */ 
    }

    public static string RezSpiderTranslate(string t)
    {
        return OptionInterface.Translate(t); //this.manager.rainWorld.inGameTranslator.BPTranslate(t);
    }


    public override void Initialize()
    {
        base.Initialize();

        //OpTab opTab = new OpTab(this, "Options");
        this.Tabs = new OpTab[]
        {
            //opTab
			new OpTab(this, "Spider Options"),
            //new OpTab(this, "Slugcat Options"), //if wanting extra menu just add new tab number for it
            //new OpTab(this, "Info")
        };

        //Add lines bellow here on menu
        float lineCount = 530;

        Tabs[0].AddItems(new OpLabel(155f, lineCount + 50, RezSpiderTranslate("Spider Options WIP Hover over for more description")));



        //float indenting = 250f;

        lineCount -= 20;
        OpSlider DartCapacitySlide = new OpSlider(RezSpiderOptions.DartCapacity, new UnityEngine.Vector2(55f, lineCount), 150, false);
        string dscDartCapacity = RezSpiderTranslate("Changes the amount of Darts you can shoot at once.");
        Tabs[0].AddItems(DartCapacitySlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Dart Capacity")) { bumpBehav = DartCapacitySlide.bumpBehav, description = dscDartCapacity });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("you will have less Darts to shoot.") });
        Tabs[0].AddItems(new OpLabel(220f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("You will have more Darts to shoot at once.") });
        DartCapacitySlide.description = dscDartCapacity;

        lineCount -= 70;
        OpFloatSlider DartRateSlide = new OpFloatSlider(RezSpiderOptions.DartFireRate, new UnityEngine.Vector2(55f, lineCount), 250, 0, false);
        string dscDartRate = RezSpiderTranslate("Changes the rate that darts recharge, one at a time in seconds.");
        Tabs[0].AddItems(DartRateSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Fire Rate")) { bumpBehav = DartRateSlide.bumpBehav, description = dscDartRate });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Fast")) { description = RezSpiderTranslate("Faster rate") });
        Tabs[0].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("Slow")) { description = RezSpiderTranslate("Slower rate") });
        DartRateSlide.description = dscDartRate;

        lineCount -= 70;
        OpFloatSlider BiteSlide = new OpFloatSlider(RezSpiderOptions.BiteDamage, new UnityEngine.Vector2(55f, lineCount), 450, 0, false);
        string dscBite = RezSpiderTranslate("How much damage your bite does.");
        Tabs[0].AddItems(BiteSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Bite damage")) { bumpBehav = BiteSlide.bumpBehav, description = dscBite });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("weaker damage") });
        Tabs[0].AddItems(new OpLabel(520f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("stronger damage") });
        BiteSlide.description = dscBite;

        lineCount -= 80;
        string dsc1 = RezSpiderTranslate("Multiplies Bite damage by 100,000!");
        OpCheckBox chkBox1 = new OpCheckBox(RezSpiderOptions.BiteOP, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox1, new OpLabel(50f, lineCount, RezSpiderTranslate("Over powered Bite!")) { bumpBehav = chkBox1.bumpBehav, description = dsc1 });
        chkBox1.description = dsc1;

        lineCount -= 35;
        string dsc2 = RezSpiderTranslate("Turn on if you want to shoot darts while holding objects. Recommended to have a custom key binding to shoot dart");
        OpCheckBox chkBox2 = new OpCheckBox(RezSpiderOptions.DartAndHold, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox2, new OpLabel(50f, lineCount, RezSpiderTranslate("Shoot darts while holding")) { bumpBehav = chkBox2.bumpBehav, description = dsc2 });
        chkBox2.description = dsc2;

        //Custom key bindings

        lineCount -= 35;
        string dsc3 = RezSpiderTranslate("Turn off to make your own key bind to shoot the darts");
        OpCheckBox chkBox3 = new OpCheckBox(RezSpiderOptions.DartBindThrow, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox3, new OpLabel(50f, lineCount, RezSpiderTranslate("Dart shoot key bind to throw button")) { bumpBehav = chkBox3.bumpBehav, description = dsc3 });
        chkBox3.description = dsc3;

        lineCount -= 50;
        Tabs[0].AddItems(new OpLabel(55f, lineCount, RezSpiderTranslate("Custom Key binds only work if Dart shoot key bind to throw is off")) { description = RezSpiderTranslate("Allows to make your own key binds to shoot the darts") });

        lineCount -= 40;
        //if (menucanselect == true) //not simply working this way and more to it to hide buttons
        //{
            Tabs[0].AddItems(new OpKeyBinder(DartBind1, new UnityEngine.Vector2(30f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
            Tabs[0].AddItems(new OpLabel(40f, lineCount - 30, RezSpiderTranslate("player 1")) { description = RezSpiderTranslate("player 1") });
            Tabs[0].AddItems(new OpKeyBinder(DartBind2, new UnityEngine.Vector2(140f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
            Tabs[0].AddItems(new OpLabel(150f, lineCount - 30, RezSpiderTranslate("player 2")) { description = RezSpiderTranslate("player 2") });
            Tabs[0].AddItems(new OpKeyBinder(DartBind3, new UnityEngine.Vector2(250f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
            Tabs[0].AddItems(new OpLabel(260f, lineCount - 30, RezSpiderTranslate("player 3")) { description = RezSpiderTranslate("player 3") });
            Tabs[0].AddItems(new OpKeyBinder(DartBind4, new UnityEngine.Vector2(360f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
            Tabs[0].AddItems(new OpLabel(370f, lineCount - 30, RezSpiderTranslate("player 4")) { description = RezSpiderTranslate("player 4") });
        //}
        


        /*               
        //Slugcat Options Tab of the menu
        lineCount = 530;
        Tabs[1].AddItems(new OpLabel(155f, lineCount + 50, RezSpiderTranslate("Slugcat Options WIP Hover over for more description")));

        lineCount -= 20;
        OpFloatSlider JumpPowerSlide = new OpFloatSlider(RezSpiderOptions.JumpPower, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
        string dscJumpPower = RezSpiderTranslate("Jump multiplier with 0 being normal jump.");
        Tabs[1].AddItems(JumpPowerSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Jump power")) { bumpBehav = JumpPowerSlide.bumpBehav, description = dscJumpPower });
        Tabs[1].AddItems(new OpLabel(5f, lineCount, RezSpiderTranslate("Weaker")) { description = RezSpiderTranslate("Jump smaller") });
        Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("Higher")) { description = RezSpiderTranslate("Jump much higher") });
        JumpPowerSlide.description = dscJumpPower;

        lineCount -= 70;
        OpFloatSlider CatWeightSlide = new OpFloatSlider(RezSpiderOptions.CatWeight, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
        string dscCatWeight = RezSpiderTranslate("slugcat mass that changes how much weight the slugcat is.");
        Tabs[1].AddItems(CatWeightSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Slugcat Weight")) { bumpBehav = CatWeightSlide.bumpBehav, description = dscCatWeight });
        Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("less mass") });
        Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("more mass") });
        CatWeightSlide.description = dscCatWeight;

                                    //Just not working for some weird reason
         lineCount -= 70;
         OpFloatSlider CatClimbSlide = new OpFloatSlider(RezSpiderOptions.CatClimb, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
         string dscCatClimb = RezSpiderTranslate("slugcat climbing speed on how fast you climb poles.");
         Tabs[1].AddItems(CatClimbSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Slugcat climb speed")) { bumpBehav = CatClimbSlide.bumpBehav, description = dscCatClimb });
         Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("less speed") });
         Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("more speed") });
         CatCatClimb.description = dscCatClimb;

         lineCount -= 70;
         OpFloatSlider CatTunnelSlide = new OpFloatSlider(RezSpiderOptions.CatTunnel, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
         string dscCatTunnel = RezSpiderTranslate("slugcat tunnel speed on how fast you go through tunnels.");
         Tabs[1].AddItems(CatTunnelSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Slugcat tunnel speed")) { bumpBehav = CatTunnelSlide.bumpBehav, description = dscCatTunnel });
         Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("less speed") });
         Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("more speed") });
         CatTunnelSlide.description = dscCatTunnel;

         lineCount -= 70;
         OpFloatSlider CatTunnelSlide = new OpFloatSlider(RezSpiderOptions.CatWalk, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
         string dscCatTunnel = RezSpiderTranslate("slugcat walk speed on how fast you walk upright.");
         Tabs[1].AddItems(CatTunnelSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Slugcat walk speed")) { bumpBehav = CatTunnelSlide.bumpBehav, description = dscCatTunnel });
         Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("less speed") });
         Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("more speed") });
         CatTunnelSlide.description = dscCatTunnel;

         lineCount -= 70;
         OpFloatSlider CatCrawlSlide = new OpFloatSlider(RezSpiderOptions.CatCrawl, new UnityEngine.Vector2(55f, lineCount), 250, 2, false) { Increment = 5 };
         string dscCatCrawl = RezSpiderTranslate("slugcat crawl speed on how fast you crawl on the ground.");
         Tabs[1].AddItems(CatCrawlSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Slugcat crawl speed")) { bumpBehav = CatCrawlSlide.bumpBehav, description = dscCatCrawl });
         Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("less speed") });
         Tabs[1].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("more speed") });
         CatCrawlSlide.description = dscCatCrawl;
         */
        /*
        lineCount -= 70;
        OpSlider FoodMinSlide = new OpSlider(RezSpiderOptions.FoodMin, new UnityEngine.Vector2(55f, lineCount), 150, false);
        string dscFoodMin = RezSpiderTranslate("How much food you need to sleep in a shelter.");
        Tabs[1].AddItems(FoodMinSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Food Min")) { bumpBehav = FoodMinSlide.bumpBehav, description = dscFoodMin });
        Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("Less food to until you can sleep") });
        Tabs[1].AddItems(new OpLabel(220f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("More food to be able to sleep in shelter") });
        FoodMinSlide.description = dscFoodMin;

        lineCount -= 70;
        OpSlider FoodMaxSlide = new OpSlider(RezSpiderOptions.FoodMax, new UnityEngine.Vector2(55f, lineCount), 300, false);
        string dscFoodMax = RezSpiderTranslate("How much food you can store total.");
        Tabs[1].AddItems(FoodMaxSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Food Max")) { bumpBehav = FoodMaxSlide.bumpBehav, description = dscFoodMax });
        Tabs[1].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("Less food to be able to store") });
        Tabs[1].AddItems(new OpLabel(370f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("More food you can have to store for later") });
        FoodMaxSlide.description = dscFoodMax;
        */
    }
}