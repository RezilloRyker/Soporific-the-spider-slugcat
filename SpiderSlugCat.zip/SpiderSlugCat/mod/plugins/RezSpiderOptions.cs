﻿using UnityEngine;
using System.Numerics;
using Menu.Remix.MixedUI;

public class RezSpiderOptions : OptionInterface
{


    public RezSpiderOptions()
    {
        //RezSpiderOptions.hardMode = this.config.Bind<bool>("hardMode", true, new ConfigurableInfo("(This is just info I guess)", null, "", new object[] { "something idk" }));


        RezSpiderOptions.DartCapacity = this.config.Bind<int>("DartCapacity", 3, new ConfigAcceptableRange<int>(1, 20));
        RezSpiderOptions.BiteDamage = this.config.Bind<float>("BiteDamage", 5f, new ConfigAcceptableRange<float>(1f, 100f));
        RezSpiderOptions.BiteOP = this.config.Bind<bool>("BiteOP", false);
        RezSpiderOptions.DartFireRate = this.config.Bind<float>("DartFireRate", 5, new ConfigAcceptableRange<float>(0, 60));
        RezSpiderOptions.DartBindThrow = this.config.Bind<bool>("DartBindThrow", true);
        RezSpiderOptions.DartAndHold = this.config.Bind<bool>("DartAndHold", false);
        RezSpiderOptions.DartBind1 = this.config.Bind<KeyCode>("DartBind1", KeyCode.None);
        RezSpiderOptions.DartBind2 = this.config.Bind<KeyCode>("DartBind2", KeyCode.None);
        RezSpiderOptions.DartBind3 = this.config.Bind<KeyCode>("DartBind3", KeyCode.None);
        RezSpiderOptions.DartBind4 = this.config.Bind<KeyCode>("DartBind4", KeyCode.None);
    }




    public static Configurable<int> DartCapacity;
    public static Configurable<float> BiteDamage;
    public static Configurable<float> DartFireRate;
    public static Configurable<bool> DartBindThrow;
    public static Configurable<bool> DartAndHold;
    public static Configurable<KeyCode> DartBind1;
    public static Configurable<KeyCode> DartBind2;
    public static Configurable<KeyCode> DartBind3;
    public static Configurable<KeyCode> DartBind4;
    public static Configurable<bool> BiteOP;


    public override void Update()
    {
        base.Update();
    }

    public static string RezSpiderTranslate(string t)
    {
        return OptionInterface.Translate(t); //this.manager.rainWorld.inGameTranslator.BPTranslate(t);
    }


    public override void Initialize()
    {
        base.Initialize();

        // OpTab opTab = new OpTab(this, "Options");
        this.Tabs = new OpTab[]
        {
            //opTab
			new OpTab(this, "Options"),
            //new OpTab(this, "Misc"),
            //new OpTab(this, "Info")
        };

        //Add lines bellow here on menu
        float lineCount = 530;

        Tabs[0].AddItems(new OpLabel(155f, lineCount + 50, RezSpiderTranslate("Options WIP Hover over for more description")));



        //float indenting = 250f;

        lineCount -= 20;
        OpSlider DartCapacitySlide = new OpSlider(RezSpiderOptions.DartCapacity, new UnityEngine.Vector2(55f, lineCount), 150, false);
        string dscDartCapacity = RezSpiderTranslate("Changes the amount of Darts you can shoot at once.");
        Tabs[0].AddItems(DartCapacitySlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Dart Capacity")) { bumpBehav = DartCapacitySlide.bumpBehav, description = dscDartCapacity });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("you will have less Darts to shoot.") });
        Tabs[0].AddItems(new OpLabel(220f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("You will have more Darts to shoot at once.") });
        DartCapacitySlide.description = dscDartCapacity;

        lineCount -= 70;
        OpFloatSlider DartRateSlide = new OpFloatSlider(RezSpiderOptions.DartFireRate, new UnityEngine.Vector2(55f, lineCount), 250, 0, false);
        string dscDartRate = RezSpiderTranslate("Changes the rate that darts recharge, one at a time in seconds.");
        Tabs[0].AddItems(DartRateSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Fire Rate")) { bumpBehav = DartRateSlide.bumpBehav, description = dscDartRate });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Fast")) { description = RezSpiderTranslate("Faster rate") });
        Tabs[0].AddItems(new OpLabel(320f, lineCount, RezSpiderTranslate("Slow")) { description = RezSpiderTranslate("Slower rate") });
        DartRateSlide.description = dscDartRate;

        lineCount -= 70;
        OpFloatSlider BiteSlide = new OpFloatSlider(RezSpiderOptions.BiteDamage, new UnityEngine.Vector2(55f, lineCount), 450, 0, false);
        string dscBite = RezSpiderTranslate("How much damage your bite does.");
        Tabs[0].AddItems(BiteSlide, new OpLabel(100f, lineCount - 15, RezSpiderTranslate("Bite damage")) { bumpBehav = BiteSlide.bumpBehav, description = dscBite });
        Tabs[0].AddItems(new OpLabel(15f, lineCount, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("weaker damage") });
        Tabs[0].AddItems(new OpLabel(520f, lineCount, RezSpiderTranslate("More")) { description = RezSpiderTranslate("stronger damage") });
        BiteSlide.description = dscBite;

        lineCount -= 80;
        string dsc1 = RezSpiderTranslate("Multiplies Bite damage by 100,000!");
        OpCheckBox chkBox1 = new OpCheckBox(RezSpiderOptions.BiteOP, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox1, new OpLabel(50f, lineCount, RezSpiderTranslate("Over powered Bite!")) { bumpBehav = chkBox1.bumpBehav, description = dsc1 });
        chkBox1.description = dsc1;

        lineCount -= 35;
        string dsc2 = RezSpiderTranslate("Turn on if you want to shoot darts while holding objects. Currently can't figure out how to make custom keybind other then Throw");
        OpCheckBox chkBox2 = new OpCheckBox(RezSpiderOptions.DartAndHold, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox2, new OpLabel(50f, lineCount, RezSpiderTranslate("Shoot darts while holding")) { bumpBehav = chkBox2.bumpBehav, description = dsc2 });
        chkBox2.description = dsc2;

        /*
        lineCount -= 35;
        string dsc3 = RezSpiderTranslate("Turn off to make your own key bind to shoot the darts");
        OpCheckBox chkBox3 = new OpCheckBox(RezSpiderOptions.DartBindThrow, new UnityEngine.Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox3, new OpLabel(50f, lineCount, RezSpiderTranslate("Dart shoot key bind to throw button")) { bumpBehav = chkBox3.bumpBehav, description = dsc3 });
        chkBox3.description = dsc3;

        lineCount -= 50;
        Tabs[0].AddItems(new OpLabel(55f, lineCount, RezSpiderTranslate("Custom Key binds only work if Dart shoot key bind to throw is off")) { description = RezSpiderTranslate("Allows to make your own key binds to shoot the darts") });

        lineCount -= 40;
        Tabs[0].AddItems(new OpKeyBinder(DartBind1, new UnityEngine.Vector2(30f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
        Tabs[0].AddItems(new OpLabel(40f, lineCount -30, RezSpiderTranslate("player 1")) { description = RezSpiderTranslate("player 1") });
        Tabs[0].AddItems(new OpKeyBinder(DartBind2, new UnityEngine.Vector2(140f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
        Tabs[0].AddItems(new OpLabel(150f, lineCount - 30, RezSpiderTranslate("player 2")) { description = RezSpiderTranslate("player 2") });
        Tabs[0].AddItems(new OpKeyBinder(DartBind3, new UnityEngine.Vector2(250f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
        Tabs[0].AddItems(new OpLabel(260f, lineCount - 30, RezSpiderTranslate("player 3")) { description = RezSpiderTranslate("player 3") });
        Tabs[0].AddItems(new OpKeyBinder(DartBind4, new UnityEngine.Vector2(360f, lineCount), new UnityEngine.Vector2(80f, 30f), true, OpKeyBinder.BindController.AnyController));
        Tabs[0].AddItems(new OpLabel(370f, lineCount - 30, RezSpiderTranslate("player 4")) { description = RezSpiderTranslate("player 4") });
        */
    }
}