﻿public class RezSpiderOptions : OptionInterface
{


    public RezSpiderOptions()
    {
        //RezSpiderOptions.hardMode = this.config.Bind<bool>("hardMode", true, new ConfigurableInfo("(This is just info I guess)", null, "", new object[] { "something idk" }));


        RezSpiderOptions.DartCapacity = this.config.Bind<int>("DartCapacity", 3, new ConfigAcceptableRange<int>(1, 20));
    }




    public static Configurable<int> DartCapacity;


    public override void Update()
    {
        base.Update();
    }

    public static string RezSpiderTranslate(string t)
    {
        return OptionInterface.Translate(t); //this.manager.rainWorld.inGameTranslator.BPTranslate(t);
    }


    public override void Initialize()
    {
        base.Initialize();

        // OpTab opTab = new OpTab(this, "Options");
        this.Tabs = new OpTab[]
        {
            //opTab
			new OpTab(this, "Options"),
            //new OpTab(this, "Misc"),
            //new OpTab(this, "Info")
        };

        //Add lines bellow here on menu
        float lineCount = 530;

        Tabs[0].AddItems(new OpLabel(175f, lineCount + 50, RezSpiderTranslate("Options")));

        float indenting = 250f;

        lineCount -= 70;
        OpSlider threshSlide = new OpSlider(RezSpiderOptions.DartCapacity, new Vector2(55f, lineCount - 0), 150, false);
        string dscThresh = RezSpiderTranslate("Changes the amount of Darts you can shoot at once");
        Tabs[0].AddItems(threshSlide, new OpLabel(50f, lineCount - 15, RezSpiderTranslate("Starting threshold")) { bumpBehav = threshSlide.bumpBehav, description = dscThresh });
        Tabs[0].AddItems(new OpLabel(15f, lineCount + 5, RezSpiderTranslate("Less")) { description = RezSpiderTranslate("you will have less Darts to shoot.") });
        Tabs[0].AddItems(new OpLabel(220f, lineCount + 5, RezSpiderTranslate("More")) { description = RezSpiderTranslate("You will have more Darts to shoot at once.") });
        threshSlide.description = dscThresh;

    }
}