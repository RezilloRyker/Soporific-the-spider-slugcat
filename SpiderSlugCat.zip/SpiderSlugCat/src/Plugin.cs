﻿using System;
using BepInEx;
using UnityEngine;
using SlugBase.Features;
using static SlugBase.Features.FeatureTypes;
using Kittehface.Framework20;
using System.Drawing.Text;
using System.Numerics;
using System.CodeDom;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Collections.Generic;
using MonoMod;
using Menu;
using SlugBase;
using System.Dynamic;

namespace slugSpiderDartSleep
{
    [BepInPlugin(MOD_ID, "Soporific", "0.1.4")]
    class Plugin : BaseUnityPlugin
    {
        private const string MOD_ID = "Rezillo.slugSpiderDartSleep";

        public static readonly PlayerFeature<bool> SpiderSpit = PlayerBool("slugSpiderDartSleep/Spider_Spit"); //plug in for custom spider spit ability
        public static readonly PlayerFeature<bool> RezSpiderSuperCrawl = PlayerBool("slugSpiderDartSleep/super_crawl"); //the crawl speed
        public static readonly PlayerFeature<float> RezSpiderSuperJump = PlayerFloat("slugSpiderDartSleep/super_jump"); //the jump power
        //private static readonly object RezSpiderOption;

        //public static readonly PlayerFeature<bool> SpiderImmuneDart = PlayerBool("slugSpiderDartSleep/Spider_DartImmune"); //plan to use for being immune to the dart maggots sleep 
        //private bool SpiderImmuneDart = false;
        private bool canspit = true;
        private bool canspitA = true;
        private bool canspitB = true;
        private bool canspitC = true;
        private bool canspitD = true;
        //public static Configurable<int> DartCapacity;
        private int SpitAmmoCapacity = 1;//RezSpiderOption.DartCapacity.Value; //how many times you can shoot darts
        private int SpitAmmoCapacityA = 1;
        private int SpitAmmoCapacityB = 1;
        private int SpitAmmoCapacityC = 1;
        private int SpitAmmoCapacityD = 1;
        private float SpitAmmoTimer = 5f; //the rate that ammo comes back
        private float SpitAmmoTimerA = 5f;
        private float SpitAmmoTimerB = 5f;
        private float SpitAmmoTimerC = 5f;
        private float SpitAmmoTimerD = 5f;
        private float crawlSpeed = 3f;
        /*
        private readonly Configurable<KeyCode> DartBind1;
         private KeyCode CustomBind1;
         private KeyCode CustomBind2;
         private KeyCode CustomBind3;
         private KeyCode CustomBind4;
         private readonly KeyCode keyCode = KeyCode.None;
        */


        /* way to possibly change settings that are adjusted by Remix menu then just on .json
        if (SlugBaseCharacter.TryGet(new SlugcatStats.Name("my slugcat id"), out var character))
{
    character.Features.Set(PlayerFeatures.MaulDamage, JsonConverter.ToJson(5f));
}
        */

        private RezSpiderOptions RezOptions;
        public Plugin()
        {
            RezOptions = new RezSpiderOptions();
        }
        public void Hook_OnModsInit(On.RainWorld.orig_OnModsInit orig, RainWorld self)
        {
            orig(self);
            try
            {
                MachineConnector.SetRegisteredOI("Rezillo.slugSpider", RezOptions);
            }
            catch (Exception ex)
            {
                /* make sure to error-proof your hook, 
                otherwise the game may break 
                in a hard-to-track way
                and other mods may stop working */
    }
}

        // public static ConditionalWeakTable<Player, StrongBox<int>> SpitAmmoCapacity = new(); //attempt to have dictionary for SpitAmmoCapacity
        
         private void PlayerState_ctor(On.PlayerState.orig_ctor orig, PlayerState self, AbstractCreature crit, int playerNumber, SlugcatStats.Name slugcatCharacter, bool isGhost)
         {
            SpitAmmoCapacity = RezSpiderOptions.DartCapacity.Value;
            SpitAmmoCapacityA = RezSpiderOptions.DartCapacity.Value;
            SpitAmmoCapacityB = RezSpiderOptions.DartCapacity.Value;
            SpitAmmoCapacityC = RezSpiderOptions.DartCapacity.Value;
            SpitAmmoCapacityD = RezSpiderOptions.DartCapacity.Value;
            SpitAmmoTimer = RezSpiderOptions.DartFireRate.Value;
            SpitAmmoTimerA = RezSpiderOptions.DartFireRate.Value;
            SpitAmmoTimerB = RezSpiderOptions.DartFireRate.Value;
            SpitAmmoTimerC = RezSpiderOptions.DartFireRate.Value;
            SpitAmmoTimerD = RezSpiderOptions.DartFireRate.Value;
            //CustomBind1 = RezSpiderOptions.DartBind1.Value;
            //CustomBind2 = RezSpiderOptions.DartBind2.Value;
            //CustomBind3 = RezSpiderOptions.DartBind3.Value;
            //CustomBind4 = RezSpiderOptions.DartBind4.Value;
            if (SlugBaseCharacter.TryGet(new SlugcatStats.Name("slugSpiderDartSleep"), out var character))
            {
                if(RezSpiderOptions.BiteOP.Value == true)
                {
                    character.Features.Set(PlayerFeatures.MaulDamage, JsonConverter.ToJson(RezSpiderOptions.BiteDamage.Value *= 100000));
                }
                if (RezSpiderOptions.BiteOP.Value == false)
                {
                    character.Features.Set(PlayerFeatures.MaulDamage, JsonConverter.ToJson(RezSpiderOptions.BiteDamage.Value));
                }
            }
            orig(self, crit, playerNumber, slugcatCharacter, isGhost);

         }
        




        // the action to spit out darts to put creatures to sleep.
        // big array for each player
        public void buttonThrowPlayerCheckToFalse(Player self)
        {
            if (self.playerState.playerNumber == 0) { canspitA = false; }
            if (self.playerState.playerNumber == 1) { canspitB = false; }
            if (self.playerState.playerNumber == 2) { canspitC = false; }
            if (self.playerState.playerNumber == 3) { canspitD = false; }
            if (self.playerState.playerNumber > 3) { canspit = false; }
        }

        public void ShootDartButtonIsPressed(Player self)
        {
            if (canspitA && self.playerState.playerNumber == 0)
            {
                if (SpitAmmoCapacityA == 0) // turns can spit to false when ammo runs out
                {
                    canspitA = false;
                }
                else
                {
                    Spit(self);
                    SpitAmmoCapacityA--;
                }
            }
            if (canspitB && self.playerState.playerNumber == 1)
            {
                if (SpitAmmoCapacityB == 0) // turns can spit to false when ammo runs out
                {
                    canspitB = false;
                }
                else
                {
                    Spit(self);
                    SpitAmmoCapacityB--;
                }
            }
            if (canspitC && self.playerState.playerNumber == 2)
            {
                if (SpitAmmoCapacityC == 0) // turns can spit to false when ammo runs out
                {
                    canspitC = false;
                }
                else
                {
                    Spit(self);
                    SpitAmmoCapacityC--;
                }
            }
            if (canspitD && self.playerState.playerNumber == 3)
            {
                if (SpitAmmoCapacityD == 0) // turns can spit to false when ammo runs out
                {
                    canspitD = false;
                }
                else
                {
                    Spit(self);
                    SpitAmmoCapacityD--;
                }
            }
            if (canspit && self.playerState.playerNumber > 3)
            {
                if (SpitAmmoCapacity == 0) // turns can spit to false when ammo runs out
                {
                    canspit = false;
                }
                else
                {
                    Spit(self);
                    SpitAmmoCapacity--;
                }
            }
        }

        public void DartRechargeCycle(Player self)
        {
            if (SpitAmmoCapacityA < RezSpiderOptions.DartCapacity.Value) //filling back up the ammo
            {
                SpitAmmoTimerA -= Time.deltaTime;
                if (SpitAmmoTimerA <= 0)
                {
                    SpitAmmoCapacityA++;
                    SpitAmmoTimerA = RezSpiderOptions.DartFireRate.Value; //the rate that ammo comes back
                }
            }
            if (SpitAmmoCapacityB < RezSpiderOptions.DartCapacity.Value) //filling back up the ammo
            {
                SpitAmmoTimerB -= Time.deltaTime;
                if (SpitAmmoTimerB <= 0)
                {
                    SpitAmmoCapacityB++;
                    SpitAmmoTimerB = RezSpiderOptions.DartFireRate.Value; //the rate that ammo comes back
                }
            }
            if (SpitAmmoCapacityC < RezSpiderOptions.DartCapacity.Value) //filling back up the ammo
            {
                SpitAmmoTimerC -= Time.deltaTime;
                if (SpitAmmoTimerC <= 0)
                {
                    SpitAmmoCapacityC++;
                    SpitAmmoTimerC = RezSpiderOptions.DartFireRate.Value; //the rate that ammo comes back
                }
            }
            if (SpitAmmoCapacityD < RezSpiderOptions.DartCapacity.Value) //filling back up the ammo
            {
                SpitAmmoTimerD -= Time.deltaTime;
                if (SpitAmmoTimerD <= 0)
                {
                    SpitAmmoCapacityD++;
                    SpitAmmoTimerD = RezSpiderOptions.DartFireRate.Value; //the rate that ammo comes back
                }
            }
            if (SpitAmmoCapacity < RezSpiderOptions.DartCapacity.Value) //filling back up the ammo
            {
                SpitAmmoTimer -= Time.deltaTime;
                if (SpitAmmoTimer <= 0)
                {
                    SpitAmmoCapacity++;
                    SpitAmmoTimer = RezSpiderOptions.DartFireRate.Value; //the rate that ammo comes back
                }
            }
        }

        public void CanSpitCapacityCheck(Player self)
        {
            if (SpitAmmoCapacityA > 0 && self.playerState.playerNumber == 0)
            {
                canspitA = true;
            }
            if (SpitAmmoCapacityB > 0 && self.playerState.playerNumber == 1)
            {
                canspitB = true;
            }
            if (SpitAmmoCapacityC > 0 && self.playerState.playerNumber == 2)
            {
                canspitC = true;
            }
            if (SpitAmmoCapacityD > 0 && self.playerState.playerNumber == 3)
            {
                canspitD = true;
            }
            if (SpitAmmoCapacity > 0 && self.playerState.playerNumber > 3)
            {
                canspit = true;
            }
        }


        public void Slugcatspit(Player self) //----------------main dart shooting engine------------------
        {
            //PlayerState_ctor(self);
            if (SpiderSpit.TryGet(self, out var spiderSpit))
            {
                if(RezSpiderOptions.DartBindThrow.Value == true)
                {
                    if ((self.grasps[0] != null || self.grasps[1] != null) && self.input[0].thrw && !RezSpiderOptions.DartAndHold.Value)
                    {
                            buttonThrowPlayerCheckToFalse(self);
                    }
                    if (!self.input[1].thrw && self.input[0].thrw) // the key bindings to detect when pressing the "Throw" button first checking the frame before if the button is up and then checks if it down
                    {
                        ShootDartButtonIsPressed(self);
                    }
                    //if (RezSpiderOptions.DartBind1.Value) {ShootDartButtonIsPressed(self);}
                    //if (RezSpiderOptions.DartBind1.Value == System.Windows.Input.GetKeyDown(RezSpiderOptions.DartBind1.Value)) {ShootDartButtonIsPressed(self);}
                }
                /*
                else //-----This be when there is custom key bind for shooting the darts-----
                {
                    //if ((self.grasps[0] != null || self.grasps[1] != null) && self.input[0].AnyInput.Equals(RezSpiderOptions.DartBind1.Value) && !RezSpiderOptions.DartAndHold.Value)
                    if ((self.grasps[0] != null || self.grasps[1] != null) && self.input[0].thrw && !RezSpiderOptions.DartAndHold.Value)
                    {
                        buttonThrowPlayerCheckToFalse(self);
                    }
                    //if (!self.input[1].AnyInput.Equals(RezSpiderOptions.DartBind1.Value) && self.input[0].AnyInput.Equals(RezSpiderOptions.DartBind1.Value))
                    if (!self.input[1].thrw && self.input[0].thrw)
                    {
                        ShootDartButtonIsPressed(self);
                    }
                }
                */
            }
            DartRechargeCycle(self);
            if(RezSpiderOptions.DartBindThrow.Value == true)
            {
                if (!self.input[0].thrw)
                {
                    CanSpitCapacityCheck(self);
                }
            }
            /* // -------------This also be for when there custom key bind setup----------
            if (RezSpiderOptions.DartBindThrow.Value == false)
            {
                //* if (Input.GetKeyDown(RezSpiderOptions.DartBind1.Value) == true) {}
                if (!RezSpiderOptions.DartBind1.Equals(self.input[0]))
                //if (!self.input[0].thrw)
                //if (!self.input[0].AnyInput.Equals(RezSpiderOptions.DartBind1.Value))
                //if (!self.input[0].AnyInput.Equals(CustomBind1))
                {
                    CanSpitCapacityCheck(self);
                }
            }
            */
        }


        // Add hooks

        public void OnEnable()
        {
            On.RainWorld.OnModsInit += Extras.WrapInit(LoadResources);
            //On.Player.Update += PlayerUpdate;
            // Put your custom hooks here!
            On.Player.Jump += Player_Jump;
            On.Player.GrabUpdate += GrabUpdate; //THIS ONE HAPPENS DEEPER WITHIN PLAYER UPDATE, PROBABLY AFTER INPUT HAS ALREADY CHECKED
            On.Player.UpdateBodyMode += Player_UpdateBodyMode; //getting player update for movement
            //On.Player.ObjectEaten += Player_ObjectEaten; //possible find popcorn plant
            //On.DartMaggot.Update += DartMaggot_Update; //for Updating DartMaggots to make my slugcat immune to it with code below
            On.RainWorld.OnModsInit += Hook_OnModsInit;
            On.PlayerState.ctor += PlayerState_ctor;
        }

        /*
         //An attempt to make darts immune to my slugcat however it keeps freezing game when hits anything but my slugcat
        private void DartMaggot_Update(On.DartMaggot.orig_Update orig, DartMaggot self, bool eu)
        {
            orig(self, eu);
            if (self.stuckInChunk != null && (self.stuckInChunk.owner as Player).slugcatStats.name.value == "slugSpiderDartSleep")
            {
                //if ((self.stuckInChunk.owner as Player).slugcatStats.name.value == "slugSpiderDartSleep") {}
                    self.Unstuck();
            }
            if (self.stuckInChunk?.owner is Player hitPlayer && hitPlayer.SlugCatClass.value = "my_slugcat_id")
            {
                self.Unstuck();
            }
        }
        */


        /* //Possible eating popcorn plant to ignore it.
private void Player_ObjectEaten(On.Player.orig_ObjectEaten orig, Player self, IPlayerEdible edible)
{
   orig(self, edible);
   if (GetInstanceID == AbstractPhysicalObject.AbstractObjectType.popcorn)
}*/

        private void Player_UpdateBodyMode(On.Player.orig_UpdateBodyMode orig, Player self)
        {
            orig(self);
            SpiderSuperCrawl(self);// effecting movement speed
        }

        public void SpiderSuperCrawl(Player self)// Changing movment speeds with crawling or walking
        {
            if (RezSpiderSuperCrawl.TryGet(self, out var supercrawl))
            {
                if (self.bodyMode == Player.BodyModeIndex.Crawl)
                {
                    self.dynamicRunSpeed[0] *= crawlSpeed;
                    self.dynamicRunSpeed[1] *= crawlSpeed;
                }
                else
                {
                    self.dynamicRunSpeed[0] *= 1f;
                    self.dynamicRunSpeed[1] *= 1f;
                }
                if (self.bodyMode == Player.BodyModeIndex.Default)
                {
                    self.dynamicRunSpeed[0] *= 1.5f;
                    self.dynamicRunSpeed[1] *= 1.5f;
                }
                //if (self.standing)
                if (self.bodyMode == Player.BodyModeIndex.Stand)
                {
                    self.dynamicRunSpeed[0] *= 0.7f;
                    self.dynamicRunSpeed[1] *= 0.7f;
                }
            }
        }
        // Implement SuperJump
        private void Player_Jump(On.Player.orig_Jump orig, Player self)
        {
            orig(self);

            if (RezSpiderSuperJump.TryGet(self, out var power))
            {
                self.jumpBoost *= 1f + power;
            }
        }

        private void GrabUpdate(On.Player.orig_GrabUpdate orig, Player self, bool eu) // Player grab update check
        {
            //THIS METHOD IS RESPONSIBLE FOR THROWING HELD OBJECTS, SO WE WANT YOUR THING TO HAPPEN RIGHT BEFORE ALL THAT STUFF HAPPENS
            Slugcatspit(self); //RUN YOUR CUSTOM THING FIRST 
            orig(self, eu); //THEN RUN THE REST OF IT
        }

        public void Spit(Player self)
        {
            // BigSpider Spit command
            // Token: 0x06000F5D RID: 3933 RVA: 0x000E8A34 File Offset: 0x000E6C34
            AbstractPhysicalObject abstractPhysicalObject = new AbstractPhysicalObject(self.room.world, AbstractPhysicalObject.AbstractObjectType.DartMaggot, null, self.abstractCreature.pos, self.room.game.GetNewID());
            abstractPhysicalObject.RealizeInRoom();
            if (self.input[0].x == 0 && self.input[0].y == 0) //checking if using direction axis
            {
                (abstractPhysicalObject.realizedObject as DartMaggot).Shoot(self.mainBodyChunk.pos, new(self.ThrowDirection, 0), self); //shooting dart and if not moving uses throw direction
            }
            else
            {
                (abstractPhysicalObject.realizedObject as DartMaggot).Shoot(self.mainBodyChunk.pos, new(self.input[0].x, self.input[0].y), self); //shoting dart direction to movement inputs
            }
            self.room.PlaySound(SoundID.Big_Spider_Spit, self.mainBodyChunk);
        }

        // Spit direction ideas:

        //new(self.input[0].x, self.input[0].y)
        //new(self.ThrowDirection,0)
        //new(self.mainBodyChunk.vel.x, self.mainBodyChunk.vel.y)


        // Load any resources, such as sprites or sounds
        private void LoadResources(RainWorld rainWorld)
        {
        }


    }
}

//Thanks to the help of
//Fish
//LastCherry
//bro
//WillowWisp
//Vigaro
//Jim
//Slime_Cubed