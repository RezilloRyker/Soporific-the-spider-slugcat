Use this template on GitHub or [download the code](https://github.com/SlimeCubed/ExampleSlugBaseMod/archive/refs/heads/master.zip), whichever is easiest.

Links:
- [Template Walkthrough](https://slimecubed.github.io/slugbase/articles/template.html) for a guide to this template.
- [SlugBase Docs](https://slimecubed.github.io/slugbase/) for information regarding custom slugcats.
- [Modding Wiki](https://rainworldmodding.miraheze.org/wiki/Downpour_Reference/Mod_Directories) for `modinfo.json` documentation.